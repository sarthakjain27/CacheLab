#include "cachelab.h"
#include<stdlib.h>
#include<unistd.h>
#include<getopt.h>
#include "contracts.h"
#include<stdio.h>
#include<math.h>
#include<strings.h>

#define unsigned long long int address;

typedef struct{
int s;
int E;
int b;
}cache_parameters;

typedef struct{
int S;
int B;
}cache_size;
int main(int argc, char **argv){
printf("%d",argc);
return 0;
}
